# CHANGELOG

## 1.1
- Sửa giả định sai `Nhận nhiệm vụ -> AssignTask`: flow chính hiện là `Nhận nhiệm vụ -> Trừng Ác Lệnh`.
- Thêm ItemID `40004000` / ScriptID `21000` cho Trừng Ác Lệnh.
- Bridge `UseBagItem` whitelist Trừng Ác Lệnh và Bảo Tàng Đồ; luôn resolve fresh live instance trước `Use=3:instanceID`.
- Gọi `Đến địa điểm` bằng semantic UI, đọc `MoveDestination` runtime và dùng AutoPath của client.
- Đến đích tự Use lệnh bài lần 2, gọi `Triệu hồi`, diff GMonster mới, select RoleID, AutoFight và kill proof.
- Sau kill tự về Ngô Giới trả nhiệm vụ và lặp 30 lượt.
- Protocol v1.1: `0x00010100`.
