#include "trungac_visual.h"

#include <windows.h>
#include <wincodec.h>
#include <objbase.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <map>
#include <vector>

namespace trungac_visual {
namespace {

struct Image {
    int w = 0;
    int h = 0;
    std::vector<std::uint8_t> bgra;
    bool valid() const { return w > 0 && h > 0 && bgra.size() == static_cast<std::size_t>(w) * h * 4u; }
};

struct ComInit {
    HRESULT hr = E_FAIL;
    bool uninit = false;
    ComInit() {
        hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
        uninit = SUCCEEDED(hr);
        if (hr == RPC_E_CHANGED_MODE) hr = S_OK;
    }
    ~ComInit() { if (uninit) CoUninitialize(); }
};

std::map<int, Image> g_templates;

bool DecodeResourceJpeg(int resourceId, Image& out, std::wstring& error) {
    HMODULE module = GetModuleHandleW(nullptr);
    HRSRC resource = FindResourceW(module, MAKEINTRESOURCEW(resourceId), RT_RCDATA);
    if (!resource) { error = L"Không tìm thấy template RCDATA"; return false; }
    HGLOBAL loaded = LoadResource(module, resource);
    const DWORD size = SizeofResource(module, resource);
    const void* bytes = loaded ? LockResource(loaded) : nullptr;
    if (!bytes || size == 0) { error = L"Template RCDATA rỗng"; return false; }

    HGLOBAL copy = GlobalAlloc(GMEM_MOVEABLE, size);
    if (!copy) { error = L"Không cấp phát được stream template"; return false; }
    void* dst = GlobalLock(copy);
    if (!dst) { GlobalFree(copy); error = L"Không lock được stream template"; return false; }
    std::memcpy(dst, bytes, size);
    GlobalUnlock(copy);

    IStream* stream = nullptr;
    if (FAILED(CreateStreamOnHGlobal(copy, TRUE, &stream)) || !stream) {
        GlobalFree(copy);
        error = L"Không tạo được WIC stream";
        return false;
    }

    ComInit com;
    if (FAILED(com.hr)) { stream->Release(); error = L"COM init cho WIC thất bại"; return false; }

    IWICImagingFactory* factory = nullptr;
    IWICBitmapDecoder* decoder = nullptr;
    IWICBitmapFrameDecode* frame = nullptr;
    IWICFormatConverter* converter = nullptr;
    bool ok = false;

    do {
        if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                                    IID_PPV_ARGS(&factory))) || !factory) {
            error = L"Không tạo được WIC factory"; break;
        }
        if (FAILED(factory->CreateDecoderFromStream(stream, nullptr, WICDecodeMetadataCacheOnLoad, &decoder)) || !decoder) {
            error = L"Không decode được template ảnh"; break;
        }
        if (FAILED(decoder->GetFrame(0, &frame)) || !frame) { error = L"Template không có frame"; break; }
        if (FAILED(factory->CreateFormatConverter(&converter)) || !converter) { error = L"Không tạo WIC converter"; break; }
        if (FAILED(converter->Initialize(frame, GUID_WICPixelFormat32bppBGRA,
                                         WICBitmapDitherTypeNone, nullptr, 0.0,
                                         WICBitmapPaletteTypeCustom))) {
            error = L"Không convert template sang BGRA"; break;
        }
        UINT w = 0, h = 0;
        if (FAILED(converter->GetSize(&w, &h)) || w == 0 || h == 0 || w > 8192 || h > 8192) {
            error = L"Kích thước template không hợp lệ"; break;
        }
        out = {};
        out.w = static_cast<int>(w);
        out.h = static_cast<int>(h);
        out.bgra.resize(static_cast<std::size_t>(w) * h * 4u);
        const UINT stride = w * 4u;
        if (FAILED(converter->CopyPixels(nullptr, stride,
                                         static_cast<UINT>(out.bgra.size()), out.bgra.data()))) {
            out = {}; error = L"Không đọc được pixel template"; break;
        }
        ok = true;
    } while (false);

    if (converter) converter->Release();
    if (frame) frame->Release();
    if (decoder) decoder->Release();
    if (factory) factory->Release();
    stream->Release();
    return ok;
}

bool GetTemplate(int resourceId, const Image*& out, std::wstring& error) {
    auto it = g_templates.find(resourceId);
    if (it == g_templates.end()) {
        Image decoded{};
        if (!DecodeResourceJpeg(resourceId, decoded, error)) return false;
        it = g_templates.emplace(resourceId, std::move(decoded)).first;
    }
    out = &it->second;
    return out->valid();
}

bool CaptureClient(HWND hwnd, Image& out, std::wstring& error) {
    if (!hwnd || !IsWindow(hwnd)) { error = L"Cửa sổ game không còn tồn tại"; return false; }
    RECT rc{};
    if (!GetClientRect(hwnd, &rc)) { error = L"Không đọc được client rect"; return false; }
    const int w = rc.right - rc.left;
    const int h = rc.bottom - rc.top;
    if (w <= 0 || h <= 0 || w > 8192 || h > 8192) { error = L"Kích thước client không hợp lệ"; return false; }

    HDC windowDc = GetDC(hwnd);
    if (!windowDc) { error = L"Không lấy được game DC"; return false; }
    HDC memDc = CreateCompatibleDC(windowDc);
    if (!memDc) { ReleaseDC(hwnd, windowDc); error = L"Không tạo được capture DC"; return false; }

    BITMAPINFO bmi{};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr;
    HBITMAP bitmap = CreateDIBSection(windowDc, &bmi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!bitmap || !bits) {
        if (bitmap) DeleteObject(bitmap);
        DeleteDC(memDc); ReleaseDC(hwnd, windowDc);
        error = L"Không tạo được DIB capture"; return false;
    }
    HGDIOBJ old = SelectObject(memDc, bitmap);
    BOOL captured = PrintWindow(hwnd, memDc, PW_CLIENTONLY | 0x00000002u /*PW_RENDERFULLCONTENT*/);
    if (!captured) captured = BitBlt(memDc, 0, 0, w, h, windowDc, 0, 0, SRCCOPY | CAPTUREBLT);

    if (captured) {
        out = {};
        out.w = w; out.h = h;
        const std::size_t bytes = static_cast<std::size_t>(w) * h * 4u;
        out.bgra.resize(bytes);
        std::memcpy(out.bgra.data(), bits, bytes);
    }

    SelectObject(memDc, old);
    DeleteObject(bitmap);
    DeleteDC(memDc);
    ReleaseDC(hwnd, windowDc);
    if (!captured || !out.valid()) { error = L"Không capture được client game"; return false; }
    return true;
}

Image ScaleTemplate(const Image& src, int liveW, int liveH, int baseW, int baseH) {
    if (!src.valid() || liveW <= 0 || liveH <= 0 || baseW <= 0 || baseH <= 0) return {};
    const int w = std::max(1, MulDiv(src.w, liveW, baseW));
    const int h = std::max(1, MulDiv(src.h, liveH, baseH));
    if (w == src.w && h == src.h) return src;
    Image dst{}; dst.w = w; dst.h = h; dst.bgra.resize(static_cast<std::size_t>(w) * h * 4u);
    for (int y = 0; y < h; ++y) {
        const int sy = std::min(src.h - 1, static_cast<int>((static_cast<long long>(y) * src.h) / h));
        for (int x = 0; x < w; ++x) {
            const int sx = std::min(src.w - 1, static_cast<int>((static_cast<long long>(x) * src.w) / w));
            const std::size_t si = (static_cast<std::size_t>(sy) * src.w + sx) * 4u;
            const std::size_t di = (static_cast<std::size_t>(y) * w + x) * 4u;
            dst.bgra[di + 0] = src.bgra[si + 0];
            dst.bgra[di + 1] = src.bgra[si + 1];
            dst.bgra[di + 2] = src.bgra[si + 2];
            dst.bgra[di + 3] = src.bgra[si + 3];
        }
    }
    return dst;
}

inline int PixelDiff(const std::uint8_t* a, const std::uint8_t* b) {
    return std::abs(static_cast<int>(a[0]) - b[0]) +
           std::abs(static_cast<int>(a[1]) - b[1]) +
           std::abs(static_cast<int>(a[2]) - b[2]);
}

double ScoreAt(const Image& frame, const Image& tpl, int x0, int y0, int sampleStep) {
    std::uint64_t diff = 0;
    std::uint64_t samples = 0;
    for (int y = 0; y < tpl.h; y += sampleStep) {
        const std::uint8_t* fp = frame.bgra.data() + (static_cast<std::size_t>(y0 + y) * frame.w + x0) * 4u;
        const std::uint8_t* tp = tpl.bgra.data() + static_cast<std::size_t>(y) * tpl.w * 4u;
        for (int x = 0; x < tpl.w; x += sampleStep) {
            diff += static_cast<std::uint64_t>(PixelDiff(fp + static_cast<std::size_t>(x) * 4u,
                                                        tp + static_cast<std::size_t>(x) * 4u));
            ++samples;
        }
    }
    if (samples == 0) return 0.0;
    return 1.0 - static_cast<double>(diff) / static_cast<double>(samples * 3ull * 255ull);
}

bool FindTemplate(const Image& frame, const Image& tpl, int rx, int ry, int rw, int rh,
                  double threshold, Match& out) {
    out = {};
    if (!frame.valid() || !tpl.valid()) return false;
    rx = std::clamp(rx, 0, frame.w);
    ry = std::clamp(ry, 0, frame.h);
    const int right = std::clamp(rx + rw, 0, frame.w);
    const int bottom = std::clamp(ry + rh, 0, frame.h);
    rw = right - rx; rh = bottom - ry;
    if (rw < tpl.w || rh < tpl.h) return true;

    const long long area = static_cast<long long>(rw) * rh;
    const int posStep = area > 800000 ? 2 : 1;
    const int sampleStep = std::max(1, std::min(tpl.w, tpl.h) / 18);
    double best = -1.0;
    int bestX = rx, bestY = ry;
    const int maxX = right - tpl.w;
    const int maxY = bottom - tpl.h;

    for (int y = ry; y <= maxY; y += posStep) {
        for (int x = rx; x <= maxX; x += posStep) {
            const double score = ScoreAt(frame, tpl, x, y, sampleStep);
            if (score > best) { best = score; bestX = x; bestY = y; }
        }
    }
    if (posStep > 1) {
        const int x0 = std::max(rx, bestX - posStep);
        const int x1 = std::min(maxX, bestX + posStep);
        const int y0 = std::max(ry, bestY - posStep);
        const int y1 = std::min(maxY, bestY + posStep);
        for (int y = y0; y <= y1; ++y) for (int x = x0; x <= x1; ++x) {
            const double score = ScoreAt(frame, tpl, x, y, sampleStep);
            if (score > best) { best = score; bestX = x; bestY = y; }
        }
    }
    best = ScoreAt(frame, tpl, bestX, bestY, 1);
    out.score = best;
    out.x = bestX; out.y = bestY; out.w = tpl.w; out.h = tpl.h;
    out.centerX = bestX + tpl.w / 2;
    out.centerY = bestY + tpl.h / 2;
    out.found = best >= threshold;
    return true;
}

} // namespace

bool Scan(HWND hwnd, int resourceId, const Roi& roi, double threshold,
          Match& match, std::wstring& error) {
    error.clear(); match = {};
    if (roi.baseW <= 0 || roi.baseH <= 0 || roi.w <= 0 || roi.h <= 0) {
        error = L"ROI scan không hợp lệ"; return false;
    }
    Image frame{};
    if (!CaptureClient(hwnd, frame, error)) return false;
    const Image* original = nullptr;
    if (!GetTemplate(resourceId, original, error) || !original) return false;
    Image tpl = ScaleTemplate(*original, frame.w, frame.h, roi.baseW, roi.baseH);
    if (!tpl.valid()) { error = L"Không scale được template"; return false; }
    const int x = MulDiv(roi.x, frame.w, roi.baseW);
    const int y = MulDiv(roi.y, frame.h, roi.baseH);
    const int w = std::max(1, MulDiv(roi.w, frame.w, roi.baseW));
    const int h = std::max(1, MulDiv(roi.h, frame.h, roi.baseH));
    return FindTemplate(frame, tpl, x, y, w, h, threshold, match);
}

} // namespace trungac_visual
