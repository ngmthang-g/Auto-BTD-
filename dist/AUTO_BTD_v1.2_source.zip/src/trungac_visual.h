#pragma once

#include <windows.h>
#include <string>

namespace trungac_visual {

constexpr int kResRoi1Image1 = 301;
constexpr int kResRoi1Image2 = 302;
constexpr int kResRoi2Order   = 303;
constexpr int kResRoi3Use     = 304;

struct Roi {
    int x = 0;
    int y = 0;
    int w = 0;
    int h = 0;
    int baseW = 0;
    int baseH = 0;
};

struct Match {
    bool found = false;
    double score = 0.0;
    int x = 0;
    int y = 0;
    int w = 0;
    int h = 0;
    int centerX = 0;
    int centerY = 0;
};

// Capture one game client frame in memory, search a resource-embedded template only
// inside the scaled ROI, and return the best match in current client coordinates.
// The template is scaled from its 880x495 capture base to the live client size.
bool Scan(HWND hwnd, int resourceId, const Roi& roi, double threshold,
          Match& match, std::wstring& error);

} // namespace trungac_visual
