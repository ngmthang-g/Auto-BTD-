# AUTO BTĐ Thần Long v1.1

Bản v1.1 sửa luồng **Trừng Ác** theo flow runtime thực tế:

1. Đi NPC **Ngô Giới** và chọn **Nhận nhiệm vụ**.
2. Chờ **Trừng Ác Lệnh** (`ItemID 40004000`, ScriptID `21000`) xuất hiện trong tay nải.
3. Use **live instance ID** trực tiếp, không cần mở tay nải bằng macro.
4. Gọi semantic **Đến địa điểm** để client tự giải destination ngẫu nhiên và AutoPath; tool đồng thời đọc `GetCurrentMoveDestination()` để có proof Map/X/Y runtime.
5. Đến nơi, rescan tay nải, Use lệnh bài lần nữa và gọi semantic **Triệu hồi**.
6. Diff strict `GMonster` trước/sau triệu hồi, select đúng RoleID mới, bật AutoFight và chờ dead/disappear proof.
7. Về Ngô Giới, chọn **Trả nhiệm vụ**, lặp tối đa 30 lượt rồi chuyển sang Bảo Tàng Đồ.

Bảo Tàng Đồ vẫn dùng `ItemID 30000000` với exact Use `3:liveInstanceID` và state/proof runtime sau mỗi mutation.

> EXE và `ThanLongCleanRouteBridge.dll` phải lấy cùng một build v1.1. Protocol đã bump lên `0x00010100` để chặn trộn bridge cũ.


## v1.2 Visual Trừng Ác
Flow Trừng Ác mới dùng 4 template ảnh nhúng trong EXE + ROI cố định theo base 880x495, hidden click/drag qua InputSyncManager, tối đa 2 lần vuốt tay nải, action gap >=500ms, proof đứng im >6s sau Đến địa điểm và AutoFight 15s trước khi về Ngô Giới trả nhiệm vụ.
