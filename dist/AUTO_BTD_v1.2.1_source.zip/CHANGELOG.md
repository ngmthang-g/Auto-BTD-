# v1.2.1 - Hidden drag F8 test

- Thêm F8 ĐIỂM ĐẦU, F8 ĐIỂM CUỐI và TEST VUỐT trực tiếp trên UI AUTO BTĐ.
- START/END được lưu theo client-coordinate + BaseW/BaseH của đúng PID đã chọn.
- TEST gọi cùng primitive `DragInternalPoint` mà AUTO Trừng Ác dùng: `TryClickUI -> UpdateUIDrag x12 -> EndUIDrag`; không di chuyển chuột Windows.
- TEST fail-closed nếu AUTO đang chạy, PID đã mất, thiếu điểm, hoặc hai điểm được lấy ở hai client-size khác nhau.

# v1.2 - Visual Trừng Ác workflow

- Ngô Giới: nhận `[Trừng Ác Lệnh]`, đóng NPC, mở lại, nhận nhiệm vụ, đóng NPC.
- Ép khoảng cách tối thiểu 500 ms giữa mọi mutable action trong flow Trừng Ác mới.
- Nhúng 4 ảnh template trực tiếp vào EXE bằng RCDATA; scan theo ROI 1/2/3 từ base 880x495.
- ROI2 tìm lệnh bài cho phép tối đa 2 hidden drag tay nải từ (620,332) tới (619,120).
- Hidden drag dùng `TryClickUI -> UpdateUIDrag x12 -> EndUIDrag`, không chiếm chuột Windows.
- Click tọa 1/2/3 theo dữ liệu đã chốt; sau Đến địa điểm yêu cầu đã có movement và đứng im liên tục >6s.
- Popup ConfirmMap được ưu tiên trong lúc chờ di chuyển.
- Lặp use lệnh bài lần 2, đóng bag, bật AutoFight đủ 15s, sau đó về Ngô Giới trả nhiệm vụ.

# CHANGELOG

## 1.1
- Sửa giả định sai `Nhận nhiệm vụ -> AssignTask`: flow chính hiện là `Nhận nhiệm vụ -> Trừng Ác Lệnh`.
- Thêm ItemID `40004000` / ScriptID `21000` cho Trừng Ác Lệnh.
- Bridge `UseBagItem` whitelist Trừng Ác Lệnh và Bảo Tàng Đồ; luôn resolve fresh live instance trước `Use=3:instanceID`.
- Gọi `Đến địa điểm` bằng semantic UI, đọc `MoveDestination` runtime và dùng AutoPath của client.
- Đến đích tự Use lệnh bài lần 2, gọi `Triệu hồi`, diff GMonster mới, select RoleID, AutoFight và kill proof.
- Sau kill tự về Ngô Giới trả nhiệm vụ và lặp 30 lượt.
- Protocol v1.1: `0x00010100`.
