from pathlib import Path
root = Path(__file__).resolve().parents[1]
controller = (root/'src/controller.cpp').read_text(encoding='utf-8-sig')
bridge = (root/'src/bridge.cpp').read_text(encoding='utf-8-sig')
protocol = (root/'src/protocol.h').read_text(encoding='utf-8-sig')
cmake = (root/'CMakeLists.txt').read_text(encoding='utf-8-sig')
version = (root/'VERSION.txt').read_text(encoding='utf-8-sig').strip()
assert version == '1.1', version
assert 'project(AutoBTD VERSION 1.1' in cmake
assert 'OUTPUT_NAME "AUTO_BTD_v1.1"' in cmake
assert 'kProtocolVersion = 0x00010100u' in protocol
assert 'kTrungAcOrderItemID = 40004000' in controller
assert 'kTrungAcOrderScriptID = 21000' in controller
assert 'BtdPhase::WaitOrder' in controller
assert 'BtdPhase::UseOrder' in controller
assert 'BtdPhase::SelectOrderAction' in controller
assert 'BtdPhase::WaitOrderTravel' in controller
assert 'BtdPhase::WaitSummonTarget' in controller
assert 'BtdPhase::FightSummoned' in controller
assert 'L"Nhận nhiệm vụ|Trừng Ác|[NHẬN]|Tiếp nhận"' in controller
assert 'L"Đến địa điểm|Đi đến địa điểm"' in controller
assert 'L"Triệu hồi"' in controller
assert 'L"Trả nhiệm vụ|Nhận thưởng|Hoàn thành|[TRẢ]"' in controller
assert 'Command::ReadMoveDestination' in controller
assert 'TRỪNG ÁC: đọc được runtime MoveDestination ẩn' in controller
assert 'Command::ScanNearbyMonsters' in controller
assert 'Command::SelectTargetByRoleID' in controller
assert 'SUMMON_TARGET_NOT_FOUND' in controller
assert 'TRUNG_AC_KILL_TIMEOUT' in controller
assert 'TRUNG_AC_ORDER_NOT_RECEIVED' in controller
assert 'WaitAssign' not in controller
# Fresh-live-instance contract: UseOrder rescans the bag before every order use.
use_order = controller[controller.index('if (btd.phase == BtdPhase::UseOrder)'):controller.index('if (btd.phase == BtdPhase::SelectOrderAction)')]
assert 'BtdScanTrungAcOrderBag' in use_order
assert 'BtdUseTrungAcOrder' in use_order
# Bridge is deliberately restricted to the two whitelisted items owned by this project.
assert 'kTrungAcOrderItemID = 40004000' in bridge
assert 'expectedItemID != kTreasureMapItemID && expectedItemID != kTrungAcOrderItemID' in bridge
assert 'std::string("3:")' in bridge
print('AUTO BTD v1.1 Trừng Ác Lệnh static contracts PASS')
